from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Simulated Database - Persistent for the session
db = {
    "students": [{"name": "Alex Johnson", "id_num": "STU-1029", "status": "Active"}],
    "teachers": [{"name": "Dr. Robert Smith", "dept": "Computer Science"}],
    "quizzes": [{"title": "Python Basics", "course": "CS101"}],
    "courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]
}

@app.route('/')
def login():
    return render_template('login.html')

# --- DASHBOARD ROUTES ---
@app.route('/dashboard/admin')
def admin_dash():
    return render_template('admin_dash.html', db=db)

@app.route('/dashboard/faculty')
def faculty_dash():
    return render_template('faculty_dash.html', db=db)

@app.route('/dashboard/student')
def student_dash():
    # Adding extra student-specific context for charts
    user_context = {
        "name": "Alex Johnson",
        "role": "student",
        "quiz_scores": [85, 70, 90, 65, 95],
        "progress_data": [
            {"name": "Python Mastery", "completed": 80, "left": 20},
            {"name": "Web Design", "completed": 45, "left": 55}
        ]
    }
    return render_template('student_dash.html', user=user_context, db=db)

@app.route('/student/feature/<name>')
def student_feature(name):
    return render_template('coming_soon.html', feature_name=name, role='student')

# --- FACULTY ACTIONS ---
@app.route('/add_quiz', methods=['POST'])
def add_quiz():
    title = request.form.get('title')
    db['quizzes'].append({"title": title, "course": "General"})
    return redirect(url_for('faculty_dash'))

@app.route('/add_course', methods=['POST'])
def add_course():
    title = request.form.get('title')
    raw_url = request.form.get('url')
    # Logic to convert regular YT link to Embed link
    if "watch?v=" in raw_url:
        embed_url = raw_url.replace("watch?v=", "embed/")
    else:
        embed_url = raw_url
    db['courses'].append({"title": title, "url": embed_url})
    return redirect(url_for('faculty_dash'))

@app.route('/add_user', methods=['POST'])
def add_user():
    role = request.form.get('user_role')
    name = request.form.get('name')
    extra = request.form.get('extra_info')
    
    if role == 'student':
        db['students'].append({"name": name, "id_num": extra, "status": "Active"})
        return redirect(url_for('admin_dash', tab='student'))
    else:
        db['teachers'].append({"name": name, "dept": extra})
        return redirect(url_for('admin_dash', tab='teacher'))

@app.route('/delete_user/<type>/<int:id>')
def delete_user(type, id):
    if type == 'student':
        db['students'].pop(id)
        return redirect(url_for('admin_dash', tab='student'))
    else:
        db['teachers'].pop(id)
        return redirect(url_for('admin_dash', tab='teacher'))

if __name__ == '__main__':
    app.run(debug=True)