# 🔐 LMS Login System Documentation

## Overview
This login system provides secure authentication for the Online Learning Management System with role-based access control for Admin, Faculty, and Student users.

## Features
- ✅ Secure password hashing (SHA-256)
- ✅ Session management
- ✅ Role-based access control
- ✅ Flash messaging for user feedback
- ✅ Auto-redirect for logged-in users
- ✅ Protected routes with decorators
- ✅ Responsive login interface

## Demo Credentials

### Student Access
- **Email:** alex.johnson@student.lms.edu
- **Password:** student123
- **Email:** sarah.wilson@student.lms.edu
- **Password:** student123

### Faculty Access
- **Email:** robert.smith@lms.edu
- **Password:** faculty123
- **Email:** jane.doe@lms.edu
- **Password:** faculty123

### Admin Access
- **Email:** admin@lms.edu
- **Password:** admin123

## How It Works

### 1. Login Process
1. User visits `/` (login page)
2. Enters email, password, and selects role
3. System validates credentials against database
4. If valid, creates session and redirects to appropriate dashboard
5. If invalid, shows error message

### 2. Session Management
- Sessions store: user_email, user_role, user_name, user_id
- Sessions persist until logout or browser close
- Auto-redirect logged-in users to their dashboard

### 3. Protected Routes
All dashboard routes are protected with `@require_login()` decorator:
- `/dashboard/admin` - Admin only
- `/dashboard/faculty` - Faculty only  
- `/dashboard/student` - Student only

### 4. Logout
- `/logout` route clears session and redirects to login
- Logout links available in all dashboards

## Integration with Team Modules

### For Quiz Module Developer
```python
@app.route('/student/quiz/<quiz_id>')
@require_login('student')
def take_quiz(quiz_id):
    # Access current user: session['user_name'], session['user_email']
    # Your quiz logic here
    pass
```

### For Content Module Developer
```python
@app.route('/student/content/<content_id>')
@require_login('student')
def view_content(content_id):
    # Access current user data
    user_email = session['user_email']
    user_data = db['users'][user_email]
    # Your content logic here
    pass
```

### For Courses Module Developer
```python
@app.route('/faculty/courses/create')
@require_login('faculty')
def create_course():
    # Access faculty info: session['user_name']
    # Your course creation logic here
    pass
```

### For Results Module Developer
```python
@app.route('/student/results')
@require_login('student')
def view_results():
    # Get student's quiz scores
    user_email = session['user_email']
    quiz_scores = db['users'][user_email]['quiz_scores']
    # Your results logic here
    pass
```

## Adding New Users

### Programmatically
```python
import hashlib

# Add new user to db['users']
new_user_email = "newuser@lms.edu"
db['users'][new_user_email] = {
    "password": hashlib.sha256("password123".encode()).hexdigest(),
    "role": "student",  # or "faculty" or "admin"
    "name": "New User Name",
    "student_id": "STU-1031"  # for students
}
```

### Through Admin Panel
Admins can add users through the existing admin dashboard interface.

## Security Features
- Passwords are hashed using SHA-256
- Session-based authentication
- Role-based access control
- CSRF protection through Flask sessions
- Input validation and sanitization

## File Structure
```
├── app.py                 # Main Flask app with auth logic
├── templates/
│   ├── login.html        # Login interface
│   ├── admin_dash.html   # Admin dashboard
│   ├── faculty_dash.html # Faculty dashboard
│   └── student_dash.html # Student dashboard
└── LOGIN_SYSTEM_README.md # This documentation
```

## Testing the System
1. Run the Flask app: `python app.py`
2. Visit `http://localhost:5000`
3. Try logging in with demo credentials
4. Test role-based access by trying to access other dashboards
5. Test logout functionality

## Next Steps for Team Integration
1. Each team member should use `@require_login()` decorator on their routes
2. Access current user data through `session` object
3. Use flash messages for user feedback: `flash('Message', 'category')`
4. Test integration with existing modules

## Troubleshooting
- **"Please log in" error:** Route needs `@require_login()` decorator
- **"Access denied" error:** User role doesn't match required role
- **Session issues:** Check if secret_key is set in Flask app
- **Password issues:** Ensure passwords are hashed with SHA-256

---
**Created by:** Login Module Team Member
**Last Updated:** January 30, 2026