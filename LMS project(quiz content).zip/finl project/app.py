from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db():
    return sqlite3.connect("lms.db")

# Home
@app.route('/')
def index():
    return render_template("index.html")

# Course Content Page
@app.route('/content')
def content():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM content")
    data = cursor.fetchall()
    db.close()
    return render_template("content.html", content=data)

# Quiz Page
@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    db = get_db()
    cursor = db.cursor()

    cursor.execute("SELECT * FROM quiz")
    questions = cursor.fetchall()

    score = 0
    if request.method == 'POST':
        for q in questions:
            selected = request.form.get(str(q[0]))
            if selected == q[5]:  # correct answer
                score += 1
        return render_template("result.html", score=score, total=len(questions))

    return render_template("quiz.html", questions=questions)

if __name__ == '__main__':
    app.run(debug=True)
