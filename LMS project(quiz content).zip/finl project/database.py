import sqlite3

conn = sqlite3.connect("lms.db")
cur = conn.cursor()

# ---------------- TABLES ---------------- #

cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT,
    role TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS quiz (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT,
    op1 TEXT,
    op2 TEXT,
    op3 TEXT,
    op4 TEXT,
    answer TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS result (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT,
    score INTEGER
)
""")

# ---------------- SAMPLE USERS ---------------- #

cur.execute("DELETE FROM users")
cur.execute("INSERT INTO users VALUES (NULL,'student','123','student')")

# ---------------- CONTENT ---------------- #

cur.execute("DELETE FROM content")
cur.execute("INSERT INTO content VALUES (NULL,'AI & Python Basics','Introduction to AI and Python Programming')")
cur.execute("INSERT INTO content VALUES (NULL,'Computer Science Fundamentals','Core concepts of CS')")

# ---------------- 25 QUIZ QUESTIONS ---------------- #

cur.execute("DELETE FROM quiz")

quiz_questions = [

# Python (1–10)
("Python is a ___ language.", "Low-level", "High-level", "Machine-level", "Assembly", "High-level"),
("Which keyword is used to define a function?", "function", "def", "fun", "define", "def"),
("Which data type is immutable?", "List", "Set", "Dictionary", "Tuple", "Tuple"),
("Which symbol is used for comments?", "//", "#", "/* */", "<!-- -->", "#"),
("Which function takes input from user?", "input()", "read()", "scan()", "get()", "input()"),
("Which loop runs fixed number of times?", "while", "do-while", "for", "repeat", "for"),
("What is output of 5+2*3?", "21", "11", "17", "13", "11"),
("Which keyword handles exceptions?", "catch", "try", "error", "except", "try"),
("Which operator checks equality?", "=", "==", "!=", "<>", "=="),
("Python file extension is?", ".java", ".py", ".c", ".html", ".py"),

# Artificial Intelligence (11–18)
("AI stands for?", "Automated Intelligence", "Artificial Intelligence", "Advanced Internet", "Applied Intelligence", "Artificial Intelligence"),
("Which is a branch of AI?", "DBMS", "Machine Learning", "Networking", "OS", "Machine Learning"),
("Which algorithm is supervised learning?", "K-Means", "Linear Regression", "Apriori", "PCA", "Linear Regression"),
("Which language is popular for AI?", "C", "Java", "Python", "HTML", "Python"),
("Which is NOT AI application?", "Chatbot", "Image Recognition", "Compiler", "Self-driving car", "Compiler"),
("Machine Learning is subset of?", "DBMS", "AI", "OS", "Networking", "AI"),
("Which library is used for AI in Python?", "NumPy", "TensorFlow", "Bootstrap", "Flask", "TensorFlow"),
("Neural Network is inspired by?", "Computer", "Human Brain", "CPU", "Database", "Human Brain"),

# Computer Science (19–25)
("CPU stands for?", "Central Processing Unit", "Control Program Unit", "Central Program Utility", "Computer Power Unit", "Central Processing Unit"),
("Which data structure follows FIFO?", "Stack", "Queue", "Tree", "Graph", "Queue"),
("Which data structure follows LIFO?", "Queue", "Array", "Stack", "Linked List", "Stack"),
("Which is an operating system?", "Python", "Windows", "HTML", "Oracle", "Windows"),
("Which is NOT programming language?", "Java", "Python", "HTML", "C++", "HTML"),
("Which component stores data permanently?", "RAM", "Cache", "Hard Disk", "Register", "Hard Disk"),
("Which protocol is used for web?", "FTP", "SMTP", "HTTP", "TCP", "HTTP")
]

for q in quiz_questions:
    cur.execute("INSERT INTO quiz VALUES (NULL,?,?,?,?,?,?)", q)

conn.commit()
conn.close()

print("Database created with 25 AI, Python & CS questions successfully!")
