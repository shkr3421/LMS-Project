from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "lms_secret_key"

# ---------------- MOCK DATABASE ----------------
courses = [
    {
        "id": 1,
        "name": "Python Programming",
        "description": "Learn Python from basics to advanced",
        "instructor": "Mr. Kumar",
        "duration": "6 Weeks",
        "level": "Beginner",
        "content": "Intro, Variables, Loops",
        "approved": True
    },
    {
        "id": 2,
        "name": "Web Development",
        "description": "HTML, CSS, JavaScript, Flask",
        "instructor": "Ms. Nidhi",
        "duration": "8 Weeks",
        "level": "Intermediate",
        "content": "HTML, CSS, JS",
        "approved": False
    }
    ,
    {
        "id": 3,
        "name": "Web Development",
        "description": "HTML, CSS, JavaScript, Flask",
        "instructor": "Ms. Nidhi",
        "duration": "8 Weeks",
        "level": "Intermediate",
        "content": "HTML, CSS, JS",
        "approved": False
    }
    ,
    {
        "id": 4,
        "name": "Web Development",
        "description": "HTML, CSS, JavaScript, Flask",
        "instructor": "Ms. Nidhi",
        "duration": "8 Weeks",
        "level": "Intermediate",
        "content": "HTML, CSS, JS",
        "approved": False
    }
    ,
    {
        "id": 5,
        "name": "Web Development",
        "description": "HTML, CSS, JavaScript, Flask",
        "instructor": "Ms. Nidhi",
        "duration": "8 Weeks",
        "level": "Intermediate",
        "content": "HTML, CSS, JS",
        "approved": False
    }
]

enrollments = []  # {username, course_id}
# ------------------------------------------------


# ---------- LOGIN ----------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        session["username"] = request.form["username"]
        session["role"] = request.form["role"]
        return redirect("/courses")
    return render_template("login.html")


# ---------- COURSES ----------
@app.route("/courses")
def courses_page():
    role = session.get("role")

    # students see only approved courses
    if role == "student":
        visible_courses = [c for c in courses if c["approved"]]
    else:
        visible_courses = courses

    return render_template(
        "courses.html",
        courses=visible_courses,
        role=role
    )


# ---------- STUDENT ENROLL ----------
@app.route("/enroll", methods=["POST"])
def enroll():
    if session.get("role") != "student":
        return "Unauthorized Access"

    enrollments.append({
        "username": session["username"],
        "course_id": int(request.form["course_id"])
    })
    return render_template("enroll_success.html")


# ---------- INSTRUCTOR: EDIT COURSE ----------
@app.route("/edit_course/<int:course_id>", methods=["GET", "POST"])
def edit_course(course_id):
    if session.get("role") != "instructor":
        return "Unauthorized Access"

    course = next(c for c in courses if c["id"] == course_id)

    if request.method == "POST":
        course["name"] = request.form["name"]
        course["description"] = request.form["description"]
        course["duration"] = request.form["duration"]
        course["level"] = request.form["level"]
        return redirect("/courses")

    return render_template("edit_course.html", course=course)


# ---------- INSTRUCTOR: UPDATE CONTENT ----------
@app.route("/update_content/<int:course_id>", methods=["GET", "POST"])
def update_content(course_id):
    if session.get("role") != "instructor":
        return "Unauthorized Access"

    course = next(c for c in courses if c["id"] == course_id)

    if request.method == "POST":
        course["content"] = request.form["content"]
        return redirect("/courses")

    return render_template("update_content.html", course=course)


# ---------- INSTRUCTOR: VIEW STUDENTS ----------
@app.route("/enrolled_students/<int:course_id>")
def enrolled_students(course_id):
    if session.get("role") != "instructor":
        return "Unauthorized Access"

    students = [
        e["username"] for e in enrollments if e["course_id"] == course_id
    ]

    course = next(c for c in courses if c["id"] == course_id)

    return render_template(
        "enrolled_students.html",
        students=students,
        course=course
    )


# ---------- ADMIN: APPROVE COURSE ----------
@app.route("/approve_course/<int:course_id>")
def approve_course(course_id):
    if session.get("role") != "admin":
        return "Unauthorized Access"

    course = next(c for c in courses if c["id"] == course_id)
    course["approved"] = True
    return redirect("/courses")


# ---------- ADMIN: DELETE COURSE ----------
@app.route("/delete_course/<int:course_id>")
def delete_course(course_id):
    if session.get("role") != "admin":
        return "Unauthorized Access"

    global courses
    courses = [c for c in courses if c["id"] != course_id]
    return redirect("/courses")


if __name__ == "__main__":
    app.run(debug=True)
