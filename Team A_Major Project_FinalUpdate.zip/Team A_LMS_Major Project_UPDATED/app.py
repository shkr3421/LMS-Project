from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import re
from sqlalchemy.orm import aliased
from datetime import datetime



app = Flask(__name__)
app.secret_key = 'smart_lms_2026'

# --- DATABASE CONFIG ---
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'lms.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db_sq = SQLAlchemy(app)

# --- MODELS ---
class User(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    name = db_sq.Column(db_sq.String(100), nullable=False) 
    username = db_sq.Column(db_sq.String(50), unique=True, nullable=False)
    email = db_sq.Column(db_sq.String(120), unique=True, nullable=False) 
    password = db_sq.Column(db_sq.String(200), nullable=False)
    role = db_sq.Column(db_sq.String(20), nullable=False)

# NEW: Quiz Model
class Quiz(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    title = db_sq.Column(db_sq.String(100), nullable=False)
    faculty_username = db_sq.Column(db_sq.String(50), nullable=False)
    questions = db_sq.relationship('Question', backref='quiz', lazy=True, cascade="all, delete-orphan")

# NEW: Question Model
class Question(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    quiz_id = db_sq.Column(db_sq.Integer, db_sq.ForeignKey('quiz.id'), nullable=False)
    question_text = db_sq.Column(db_sq.Text, nullable=False)
    op1 = db_sq.Column(db_sq.String(100), nullable=False)
    op2 = db_sq.Column(db_sq.String(100), nullable=False)
    op3 = db_sq.Column(db_sq.String(100), nullable=False)
    op4 = db_sq.Column(db_sq.String(100), nullable=False)
    correct_ans = db_sq.Column(db_sq.String(10), nullable=False)

class QuizResult(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    student_username = db_sq.Column(db_sq.String(50), nullable=False)
    quiz_id = db_sq.Column(db_sq.Integer, nullable=False)
    score = db_sq.Column(db_sq.Integer, nullable=False)
    __table_args__ = (
        db_sq.UniqueConstraint('student_username', 'quiz_id'),
    )

class Course(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    title = db_sq.Column(db_sq.String(200), nullable=False)
    description = db_sq.Column(db_sq.String(300))
    video_url = db_sq.Column(db_sq.String(500), nullable=False)
    added_by = db_sq.Column(db_sq.String(100), nullable=False)


class Enrollment(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    student_username = db_sq.Column(db_sq.String(50), nullable=False)
    course_id = db_sq.Column(db_sq.Integer, nullable=False)
    progress = db_sq.Column(db_sq.Integer, default=0)  # 👈 percentage watched

class QuizAttempt(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    student_username = db_sq.Column(db_sq.String(100))
    quiz_id = db_sq.Column(db_sq.Integer, db_sq.ForeignKey('quiz.id'))
    score = db_sq.Column(db_sq.Integer)
    created_at = db_sq.Column(db_sq.DateTime, default=datetime.utcnow)


with app.app_context():
    db_sq.create_all()


def is_strong_password(password):
    pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{6,}$'
    return re.match(pattern, password)

# --- LOGIN/SIGNUP LOGIC ---
@app.route('/auth', methods=['POST'])
def auth():
    action = request.form.get('action')
    name = request.form.get('name')
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role')

    # ---------- SIGNUP ----------
    if action == 'signup':

        # 🔒 STRONG PASSWORD CHECK
        if not is_strong_password(password):
            flash("Password must be at least 6 characters and include uppercase, lowercase, number & symbol")
            return redirect(url_for('login_page'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('login_page'))

        if User.query.filter_by(email=email).first():
            flash('Email already exists!')
            return redirect(url_for('login_page'))

        new_user = User(
            name=name,
            username=username,
            email=email,
            password=generate_password_hash(password),
            role=role
        )

        db_sq.session.add(new_user)
        db_sq.session.commit()

        flash('Account created! Please login.')
        return redirect(url_for('login_page'))

    # ---------- LOGIN ----------
    else:
        user = User.query.filter_by(username=username, role=role).first()

        if user and check_password_hash(user.password, password):
            session['username'] = user.username
            session['full_name'] = user.name
            session['role'] = user.role
            return redirect(url_for(f'{user.role}_dash'))

        flash('Invalid login for selected role.')
        return redirect(url_for('login_page'))


@app.route('/add_quiz', methods=['POST'])
def add_quiz():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    title = request.form.get('title').strip()
    faculty = session['username']

    # 1️⃣ Check if quiz with this title already exists for this faculty
    quiz = Quiz.query.filter_by(
        title=title,
        faculty_username=faculty
    ).first()

    # 2️⃣ If not, create the quiz ONCE
    if not quiz:
        quiz = Quiz(
            title=title,
            faculty_username=faculty
        )
        db_sq.session.add(quiz)
        db_sq.session.flush()   # ensures quiz.id is available

    # 3️⃣ Add a new question to the SAME quiz
    question = Question(
        quiz_id=quiz.id,
        question_text=request.form.get('question_text'),
        op1=request.form.get('op1'),
        op2=request.form.get('op2'),
        op3=request.form.get('op3'),
        op4=request.form.get('op4'),
        correct_ans=request.form.get('correct_ans')
    )

    db_sq.session.add(question)
    db_sq.session.commit()

    flash("Question added to the quiz successfully!")
    return redirect(url_for('faculty_dash'))

# --- DASHBOARD ROUTES ---
@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/dashboard/student')
def student_dash():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    results = db_sq.session.query(
        Quiz.title,
        QuizResult.score
    ).join(Quiz, Quiz.id == QuizResult.quiz_id)\
     .filter(QuizResult.student_username == session['username'])\
     .all()

    quiz_data = [
        {"title": r[0], "score": r[1]}
        for r in results
    ]

    user_context = {
        "name": session.get('full_name', 'Student'),
        "quiz_data": quiz_data,
        "quiz_scores": [q["score"] for q in quiz_data],
        "quiz_titles": [q["title"] for q in quiz_data]
    }

    data_context = {
        "courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]
    }

    return render_template(
        'student_dash.html',
        user=user_context,
        db=data_context
    )


@app.route("/dashboard/admin")
def admin_dash():
    return render_template(
        "admin_dash.html",
        admin_name=session["username"],
        users=User.query.all(),
        students=User.query.filter_by(role="student").all(),
        faculty=User.query.filter_by(role="faculty").all()
    )


@app.route('/admin/add-user', methods=['POST'])
def admin_add_user():
    if session.get('role') != 'admin':
        return redirect(url_for('login_page'))

    name = request.form['name']
    username = request.form['username']
    email = request.form['email']
    raw_password = request.form['password']
    role = request.form['role']

    # 🔒 STRONG PASSWORD CHECK
    if not is_strong_password(raw_password):
        flash("Password must be at least 6 characters and include uppercase, lowercase, number & symbol")
        return redirect(url_for('admin_dash'))

    if User.query.filter_by(username=username).first():
        flash("Username already exists")
        return redirect(url_for('admin_dash'))

    if User.query.filter_by(email=email).first():
        flash("Email already exists")
        return redirect(url_for('admin_dash'))

    user = User(
        name=name,
        username=username,
        email=email,
        password=generate_password_hash(raw_password),
        role=role
    )

    db_sq.session.add(user)
    db_sq.session.commit()

    flash("User added successfully")
    return redirect(url_for('admin_dash'))


@app.route('/admin/delete-user/<int:user_id>', methods=['POST'])
def admin_delete_user(user_id):
    if session.get('role') != 'admin':
        return {"status": "unauthorized"}, 401

    user = User.query.get(user_id)
    if user:
        db_sq.session.delete(user)
        db_sq.session.commit()

    return {"status": "deleted"}


@app.route('/admin/update-user/<int:user_id>', methods=['POST'])
def update_user(user_id):
    user = User.query.get_or_404(user_id)

    data = request.get_json()
    user.name = data['name']
    user.username = data['username']
    user.role = data['role']

    db_sq.session.commit()
    return {"status": "updated"}


@app.route("/api/admin/users")
def api_all_users():
    if session.get("role") != "admin":
        return {"error": "Unauthorized"}, 403

    users = User.query.all()

    return {
        "users": [
            {
                "id": u.id,
                "name": u.name,
                "username": u.username,
                "role": u.role
            }
            for u in users
        ]
    }


@app.route('/dashboard/faculty')
def faculty_dash():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    courses = Course.query.filter_by(added_by=session['username']).all()
    quizzes = Quiz.query.filter_by(faculty_username=session['username']).all()

    return render_template(
        'faculty_dash.html',
        username=session['username'],
        courses=courses,
        quizzes=quizzes
    )



@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))



@app.route("/student/quizzes")
def available_quizzes():
    Faculty = aliased(User)

    quizzes = (
        db_sq.session.query(
            Quiz.id,
            Quiz.title,
            Quiz.faculty_username,
            Faculty.name.label("faculty_name")
        )
        .join(Faculty, Quiz.faculty_username == Faculty.username)
        .all()
    )

    return render_template(
        "student_quizzes.html",
        quizzes=quizzes
    )


@app.route('/student/quiz/<int:quiz_id>')
def take_quiz(quiz_id):
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz.id).all()

    return render_template(
        'take_quiz.html',
        quiz=quiz,
        questions=questions
    )

@app.route('/student/quiz/submit/<int:quiz_id>', methods=['POST'])
def submit_quiz(quiz_id):
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    total = len(questions)
    correct = 0

    for q in questions:
        selected = request.form.get(f"q_{q.id}")
        if selected == q.correct_ans:
            correct += 1

    percentage = round((correct / total) * 100, 2)

    username = session['username']

    # ✅ 1. SAVE ATTEMPT (NEVER OVERWRITE)
    db_sq.session.add(
        QuizAttempt(
            student_username=username,
            quiz_id=quiz_id,
            score=percentage
        )
    )

    # ✅ 2. UPDATE SUMMARY TABLE (LATEST SCORE ONLY)
    existing_result = QuizResult.query.filter_by(
        student_username=username,
        quiz_id=quiz_id
    ).first()

    if existing_result:
        existing_result.score = percentage
    else:
        db_sq.session.add(
            QuizResult(
                student_username=username,
                quiz_id=quiz_id,
                score=percentage
            )
        )

    db_sq.session.commit()

    return render_template(
        'quiz_result.html',
        score=percentage,
        correct=correct,
        total=total
    )


@app.route('/seed_courses')
def seed_courses():
    if Course.query.first():
        return "Courses already exist"

    courses = [
        ("Java for Beginners", "Complete Java fundamentals for beginners", "https://www.youtube.com/embed/grEKMHGYyns"),
        ("Data Structures in Java", "Learn arrays, stacks, queues, linked lists", "https://www.youtube.com/embed/BBpAmxU_NQo"),
        ("Python for Beginners", "Python basics to advanced concepts", "https://www.youtube.com/embed/_uQrJ0TkZlc"),
        ("C++ Full Course", "Complete C++ programming for interviews", "https://www.youtube.com/embed/vLnPwxZdW4Y"),
        ("Operating Systems", "OS concepts for software engineers", "https://www.youtube.com/embed/26QPDBe-NB8"),
        ("DBMS Full Course", "Database management systems concepts", "https://www.youtube.com/embed/HXV3zeQKqGY"),
        ("Computer Networks", "Networking fundamentals explained", "https://www.youtube.com/embed/qiQR5rTSshw"),
        ("System Design Basics", "System design fundamentals", "https://www.youtube.com/embed/UzLMhqg3_Wc"),
        ("Git & GitHub", "Version control with Git", "https://www.youtube.com/embed/RGOj5yH7evk"),
        ("REST APIs", "RESTful API design", "https://www.youtube.com/embed/Q-BpqyOT3a8"),
    ]

    for title, desc, url in courses:
        db_sq.session.add(
            Course(
                title=title,
                description=desc,
                video_url=url,
                added_by="system"   # ✅ REQUIRED FIX
            )
        )

    db_sq.session.commit()
    return "Seed courses added successfully"

@app.route('/student/library')
def content_library():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    courses = Course.query.all()
    enrolled_ids = [
        e.course_id for e in Enrollment.query.filter_by(
            student_username=session['username']
        ).all()
    ]

    return render_template(
        'content_library.html',
        courses=courses,
        enrolled_ids=enrolled_ids
    )


@app.route('/student/enroll/<int:course_id>', methods=['POST'])
def enroll_course(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    already = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if not already:
        db_sq.session.add(
            Enrollment(
                student_username=session['username'],
                course_id=course_id
            )
        )
        db_sq.session.commit()

    return {"status": "enrolled"}


@app.route('/student/my-courses')
def my_courses():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    data = db_sq.session.query(
        Course.id,
        Course.title,
        Course.description,
        Enrollment.progress
    ).join(
        Enrollment, Course.id == Enrollment.course_id
    ).filter(
        Enrollment.student_username == session['username']
    ).all()

    courses = [
        {
            "id": d.id,
            "title": d.title,
            "description": d.description,
            "progress": d.progress
        }
        for d in data
    ]

    return render_template('my_courses.html', courses=courses)



@app.route('/student/remove/<int:course_id>', methods=['POST'])
def remove_course(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if enrollment:
        db_sq.session.delete(enrollment)
        db_sq.session.commit()

    return {"status": "removed"}

@app.route('/student/update-progress/<int:course_id>', methods=['POST'])
def update_progress(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if not enrollment:
        return {"status": "not_found"}, 404

    progress = int(request.json.get("progress", 0))
    enrollment.progress = min(100, max(progress, enrollment.progress))

    db_sq.session.commit()
    return {"status": "updated", "progress": enrollment.progress}


@app.route("/student/course/<int:course_id>")
def student_course(course_id):
    course = Course.query.get_or_404(course_id)

    print("VIDEO URL FROM DB:", course.video_url)  # 🔴 THIS LINE IS IMPORTANT

    return render_template(
        "watch_course.html",
        course=course
    )

@app.route('/student/unenroll/<int:course_id>', methods=['POST'])
def unenroll_course(course_id):
    if session.get('role') != 'student':
        return {"status": "unauthorized"}, 401

    enrollment = Enrollment.query.filter_by(
        student_username=session['username'],
        course_id=course_id
    ).first()

    if not enrollment:
        return {"status": "not_found"}

    db_sq.session.delete(enrollment)
    db_sq.session.commit()

    print("UNENROLLED COURSE:", course_id)  # DEBUG
    return {"status": "unenrolled"}

@app.route('/student/exam-results')
def exam_results():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    username = session['username']
    quizzes = Quiz.query.all()

    results = []

    for quiz in quizzes:
        attempts = (
            QuizAttempt.query
            .filter_by(student_username=username, quiz_id=quiz.id)
            .order_by(QuizAttempt.created_at.asc())
            .all()
        )

        if attempts:
            scores = [int(a.score) for a in attempts]

            results.append({
                "title": quiz.title,
                "latest_score": scores[-1],   # ✅ THIS WAS MISSING
                "attempts": scores            # ✅ THIS WAS MISSING
            })

    print("DEBUG RESULTS:", results)  # 👈 MUST PRINT REAL VALUES

    return render_template(
        "student/exam_results.html",
        results=results
    )



@app.route('/student/results')
def student_results():
    if session.get('role') != 'student':
        return redirect(url_for('login_page'))

    results = db_sq.session.query(
        Quiz.title,
        QuizResult.score
    ).join(
        Quiz, Quiz.id == QuizResult.quiz_id
    ).filter(
        QuizResult.student_username == session['username']
    ).all()

    exam_results = [
        {
            "title": r.title,
            "score": r.score
        }
        for r in results
    ]

    return render_template(
        'exam_results.html',
        results=exam_results
    )

@app.route('/__delete_all_quizzes')
def delete_all_quizzes():
    with app.app_context():
        QuizResult.query.delete()
        Question.query.delete()
        Quiz.query.delete()
        db_sq.session.commit()

    return "✅ ALL quizzes, questions, and results deleted successfully"

@app.route('/faculty/quiz-performance')
def faculty_quiz_performance():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    faculty = session['username']

    results = db_sq.session.query(
        User.name.label('student_name'),
        Quiz.title.label('quiz_title'),
        QuizResult.score
    ).join(
        QuizResult, User.username == QuizResult.student_username
    ).join(
        Quiz, Quiz.id == QuizResult.quiz_id
    ).filter(
        Quiz.faculty_username == faculty
    ).all()

    performance = [
        {
            "student": r.student_name,
            "quiz": r.quiz_title,
            "score": r.score
        }
        for r in results
    ]

    return render_template(
        'faculty_quiz_performance.html',
        performance=performance
    )
    
@app.route('/faculty/add-course', methods=['POST'])
def faculty_add_course():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    title = request.form.get('title', '').strip()
    link = request.form.get('link', '').strip()

    if not title or not link:
        flash("Course title and YouTube link are required")
        return redirect(url_for('faculty_dash'))

    # ✅ Extract YouTube video ID safely
    video_id = None

    if "youtube.com/watch?v=" in link:
        video_id = link.split("watch?v=")[1].split("&")[0]
    elif "youtu.be/" in link:
        video_id = link.split("youtu.be/")[1].split("?")[0]
    else:
        flash("Please enter a valid YouTube URL")
        return redirect(url_for('faculty_dash'))

    video_id = video_id.strip()

    # ✅ Save ONLY video_id
    new_course = Course(
        title=title,
        description=f"{title} - Added by Faculty",
        video_url=video_id,
        added_by=session['username']
    )

    db_sq.session.add(new_course)
    db_sq.session.commit()

    flash("Course published successfully!")
    return redirect(url_for('faculty_dash'))



@app.route('/faculty/delete-course/<int:course_id>', methods=['POST'])
def delete_course(course_id):
    if session.get('role') != 'faculty':
        return {"status": "unauthorized"}, 401

    course = Course.query.get_or_404(course_id)

    # 🔥 Remove all enrollments related to this course
    Enrollment.query.filter_by(course_id=course_id).delete()

    # 🔥 Delete the course itself
    db_sq.session.delete(course)
    db_sq.session.commit()

    return {"status": "deleted"}

@app.route('/faculty/delete-quiz/<int:quiz_id>', methods=['POST'])
def faculty_delete_quiz(quiz_id):
    if session.get('role') != 'faculty':
        return {"status": "unauthorized"}, 401

    quiz = Quiz.query.filter_by(
        id=quiz_id,
        faculty_username=session['username']
    ).first_or_404()

    # This automatically deletes related questions due to cascade
    db_sq.session.delete(quiz)
    db_sq.session.commit()

    return {"status": "deleted"}

@app.route('/faculty/my-quizzes')
def faculty_my_quizzes():
    if session.get('role') != 'faculty':
        return redirect(url_for('login_page'))

    quizzes = Quiz.query.filter_by(
        faculty_username=session['username']
    ).all()

    # Convert quizzes to serializable format
    serializable_quizzes = []
    for quiz in quizzes:
        quiz_dict = {
            'id': quiz.id,
            'title': quiz.title,
            'questions': []
        }
        
        # Convert each question to a dictionary
        for question in quiz.questions:
            question_dict = {
                'id': question.id,
                'question_text': question.question_text,
                'op1': question.op1,
                'op2': question.op2,
                'op3': question.op3,
                'op4': question.op4,
                'correct_ans': question.correct_ans
            }
            quiz_dict['questions'].append(question_dict)
        
        serializable_quizzes.append(quiz_dict)

    return render_template(
        'faculty_my_quizzes.html',
        quizzes=serializable_quizzes,
        username=session['username']
    )


if __name__ == '__main__':
    app.run(debug=True)