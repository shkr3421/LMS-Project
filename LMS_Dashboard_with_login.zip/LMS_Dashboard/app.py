from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'smart_lms_2026'

# --- DATABASE CONFIG ---
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'lms.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db_sq = SQLAlchemy(app)

# Updated Model with Name and Email
class User(db_sq.Model):
    id = db_sq.Column(db_sq.Integer, primary_key=True)
    name = db_sq.Column(db_sq.String(100), nullable=False) 
    username = db_sq.Column(db_sq.String(50), unique=True, nullable=False)
    email = db_sq.Column(db_sq.String(120), unique=True, nullable=False) 
    password = db_sq.Column(db_sq.String(200), nullable=False)
    role = db_sq.Column(db_sq.String(20), nullable=False)

with app.app_context():
    # FORCE RESET: This line deletes the old table so the new columns can be added.
    # After you run the app once and it works, you can comment the next line out.
    db_sq.drop_all() 
    db_sq.create_all()

# --- LOGIN/SIGNUP LOGIC ---
@app.route('/auth', methods=['POST'])
def auth():
    action = request.form.get('action')
    name = request.form.get('name') 
    username = request.form.get('username')
    email = request.form.get('email') 
    password = request.form.get('password')
    role = request.form.get('role')

    if action == 'signup':
        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('login_page'))
        
        new_user = User(
            name=name, 
            username=username, 
            email=email, 
            password=generate_password_hash(password), 
            role=role
        )
        db_sq.session.add(new_user)
        db_sq.session.commit()
        flash('Account created! Please login.')
        return redirect(url_for('login_page'))
    else:
        # We query by username and role
        user = User.query.filter_by(username=username, role=role).first()
        if user and check_password_hash(user.password, password):
            session['username'] = user.username
            session['full_name'] = user.name 
            session['role'] = user.role
            return redirect(url_for(f'{user.role}_dash'))
        flash('Invalid login for selected role.')
        return redirect(url_for('login_page'))

# --- DASHBOARD ROUTES ---
@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/dashboard/student')
def student_dash():
    if session.get('role') != 'student': return redirect(url_for('login_page'))
    user_context = {"name": session.get('full_name', 'Student'), "quiz_scores": [85, 72, 90, 68, 95]}
    data_context = {"courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]}
    return render_template('student_dash.html', user=user_context, db=data_context)

@app.route('/dashboard/admin')
def admin_dash():
    if session.get('role') != 'admin': return redirect(url_for('login_page'))
    students_query = User.query.filter_by(role='student').all()
    teachers_query = User.query.filter_by(role='faculty').all()
    data_context = {
        "students": [{"id": s.id, "name": s.name, "id_num": "STU-" + str(s.id)} for s in students_query],
        "teachers": [{"id": t.id, "name": t.name, "dept": "General Academics"} for t in teachers_query]
    }
    return render_template('admin_dash.html', username=session.get('full_name', 'Admin'), db=data_context)

@app.route('/add_user', methods=['POST'])
def add_user():
    if session.get('role') != 'admin': return redirect(url_for('login_page'))
    name = request.form.get('name')
    role = request.form.get('user_role') 
    new_user = User(name=name, username=name, email=f"{name}@lms.com", password=generate_password_hash("password123"), role=role)
    db_sq.session.add(new_user)
    db_sq.session.commit()
    return redirect(url_for('admin_dash'))

@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    if session.get('role') != 'admin': return redirect(url_for('login_page'))
    user = User.query.get(user_id)
    if user:
        db_sq.session.delete(user)
        db_sq.session.commit()
    return redirect(url_for('admin_dash'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

@app.route('/dashboard/faculty')
def faculty_dash():
    if session.get('role') != 'faculty': return redirect(url_for('login_page'))
    data_context = {"courses": [{"title": "Advanced Web Dev", "url": "https://www.youtube.com/embed/qz0aGYrrlhU"}]}
    return render_template('faculty_dash.html', username=session.get('full_name', 'Faculty'), db=data_context)

if __name__ == '__main__':
    app.run(debug=True)