from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

# ---------------- DB CONNECTION ----------------
def get_db():
    conn = sqlite3.connect("lms.db")
    conn.row_factory = sqlite3.Row
    return conn


# ---------------- LOGIN ----------------
@app.route('/')
def login():
    return render_template('login.html')


# ---------------- DASHBOARDS ----------------
@app.route('/dashboard/admin')
def admin_dash():
    return render_template('admin_dash.html')

@app.route('/dashboard/faculty')
def faculty_dash():
    return render_template('faculty_dash.html')

@app.route('/dashboard/student')
def student_dash():
    user_context = {
        "name": "Alex Johnson",
        "quiz_scores": [85, 70, 90]
    }
    return render_template('student_dash.html', user=user_context)


# ---------------- CONTENT ----------------
@app.route('/content')
def content():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM content")
    courses = cur.fetchall()
    conn.close()

    return render_template("content.html", courses=courses)

# ---------------- QUIZ ----------------
@app.route('/quiz/<int:quiz_id>', methods=['GET', 'POST'])
def quiz(quiz_id):
    print("QUIZ ROUTE HIT", quiz_id) 
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM quiz")
    rows = cur.fetchall()
    conn.close()

    # Build quiz dictionary
    quiz = {
        "id": quiz_id,
        "title": "Online Quiz",
        "questions": []
    }

    for row in rows:
        quiz["questions"].append({
            "question": row["question"],
            "options": [row["op1"], row["op2"], row["op3"], row["op4"]],
            "answer": row["answer"]
        })

    form_data = request.form if request.method == 'POST' else None

    if request.method == 'POST':
        score = 0
        for idx, q in enumerate(quiz["questions"]):
            selected = request.form.get(f"q{idx}")
            if selected == q["answer"]:
                score += 1

        return render_template(
            "result.html",
            score=score,
            total=len(quiz["questions"]),
            quiz=quiz
        )

    # Pass form_data so template can pre-check selections
    return render_template("quiz.html", quiz=quiz, form_data=form_data)




# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)
